# eZwizard3-bot
A discord bot that connects to your jb ps4 to allow other people to do save things with it 
